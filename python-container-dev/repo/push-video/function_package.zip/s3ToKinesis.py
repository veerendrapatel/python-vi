import json
import boto3
import botocore
import requests

# Initialize the S3 and Kinesis Video clients
s3_client = boto3.client("s3")
kvs_client = boto3.client("kinesisvideo")

def lambda_handler(event, context):
    # Input parameters
    s3_bucket = "veer-temp-videos"
    s3_key = "video1.mp4"
    kinesis_stream_name = "video-stream-1"

    # Download the MP4 file from S3
    try:
        local_file_path = "/tmp/video.mp4"  # Temp storage for Lambda environment
        s3_client.download_file(s3_bucket, s3_key, local_file_path)
        print(f"Downloaded {s3_key} from S3 bucket {s3_bucket}")
    except botocore.exceptions.ClientError as e:
        print(f"Failed to download video from S3: {e}")
        return {"statusCode": 500, "body": json.dumps("Error downloading video from S3")}

    # Get the Kinesis Video Stream endpoint
    try:
        response = kvs_client.get_data_endpoint(
            StreamName=kinesis_stream_name,
            APIName="PUT_MEDIA"
        )
        endpoint_url = response["DataEndpoint"]
        print(f"Endpoint URL for Kinesis Video Stream: {endpoint_url}")
    except botocore.exceptions.ClientError as e:
        print(f"Failed to get Kinesis Video Stream endpoint: {e}")
        return {"statusCode": 500, "body": json.dumps("Error getting Kinesis endpoint")}

    # Stream the video to Kinesis Video Streams using requests
    try:
        headers = {
            'Content-Type': 'application/json',
            'x-amzn-stream-name': kinesis_stream_name,
        }

        with open(local_file_path, 'rb') as video_file:
            response = requests.post(
                f"{endpoint_url}/putMedia",
                headers=headers,
                data=video_file,
                stream=True
            )

        # Check response status
        if response.status_code == 200:
            print(f"Successfully streamed video to Kinesis Video Stream {kinesis_stream_name}")
            return {
                "statusCode": 200,
                "body": json.dumps("Video successfully streamed to Kinesis Video Stream")
            }
        else:
            print(f"Failed to stream video to Kinesis Video Stream: {response.text}")
            return {
                "statusCode": 500,
                "body": json.dumps("Error streaming video to Kinesis")
            }

    except Exception as e:
        print(f"Failed to stream video to Kinesis Video Stream: {e}")
        return {"statusCode": 500, "body": json.dumps("Error streaming video to Kinesis")}

